package jiake.contro;

public interface PathObserver {
    void onPathChanged(String newPath);
}
