package jiake.global;

public enum ComType {
    COPY,
    ZIP,
    UNZIP,
    GENKEY,
    GENPUB,
    ENCRY,
}
