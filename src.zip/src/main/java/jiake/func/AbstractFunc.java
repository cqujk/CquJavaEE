package jiake.func;

public abstract class AbstractFunc {
    public abstract <T, R> R func(T... args);
}